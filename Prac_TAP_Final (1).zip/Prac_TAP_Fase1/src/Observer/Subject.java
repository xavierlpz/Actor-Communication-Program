package Observer;

import Actors.Actor;
import Message.Message;

public interface Subject {
    public void attach(String name, ActorListener listener);
    public void detach(String name, ActorListener listener);
    public void notify(Message message, Actor receiverActor);
    public void attachAll();
}
