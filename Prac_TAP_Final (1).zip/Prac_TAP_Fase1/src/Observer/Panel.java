package Observer;

public class Panel implements ActorListener{
    String name;

    public Panel (String name) {
        this.name = name;
    }
    @Override
    public void created() {
        System.out.println("The actor " + name + " has been created");
    }

    @Override
    public void error() {
        System.out.println("The actor "+name+" has returned an error");
    }

    @Override
    public void stop() {
        System.out.println("The actor "+name+" has been stopped");
    }

    @Override
    public void received() {
        //System.out.println("The actor "+name+" has received a message");
    }

}
