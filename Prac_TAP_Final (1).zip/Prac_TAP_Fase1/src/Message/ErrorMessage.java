package Message;

import Actors.ActorProxy;

import java.time.LocalDateTime;

public class ErrorMessage extends Message{
    ActorProxy name;
    String message;

    public ErrorMessage(ActorProxy name) {
        this.name = name;
        this.message = "Error at " + LocalDateTime.now();
    }

    public ActorProxy getName() {
        return name;
    }

    public void setName(ActorProxy name) {
        this.name = name;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}
