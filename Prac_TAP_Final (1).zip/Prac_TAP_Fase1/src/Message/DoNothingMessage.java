package Message;

import Actors.ActorProxy;

public class DoNothingMessage extends Message{
    ActorProxy name;
    String message;

    public DoNothingMessage(ActorProxy name, String message) {
        this.name = name;
        this.message = message;
    }

    public ActorProxy getName() {
        return name;
    }

    public void setName(ActorProxy name) {
        this.name = name;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }


}
