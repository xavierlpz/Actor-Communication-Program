package Message;

import Actors.ActorProxy;

public class AddActorMessage extends Message {
    ActorProxy first;
    String message;

    public AddActorMessage (ActorProxy name, String message) {
        this.first = name;
        this.message = message;

    }

    public ActorProxy getName() {
        return first;
    }

    public void setName(ActorProxy name) {
        this.first = name;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}
