package Message;

import Actors.ActorProxy;
import Observer.Event;

import java.time.LocalDateTime;

public class CreateMessage extends Message{
    ActorProxy name;
    String message;


    public CreateMessage(ActorProxy name) {
        this.name = name;
        this.message = "Created at " + LocalDateTime.now();
        super.setEvent(Event.CREATED);
    }

    public ActorProxy getName() {
        return name;
    }

    public void setName(ActorProxy name) {
        this.name = name;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }



}
