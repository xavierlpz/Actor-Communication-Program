package Message;

import Actors.ActorProxy;
import Observer.Event;

import java.security.spec.ECField;

public abstract class Message {
    Event event = Event.RECEIVED;

    public abstract ActorProxy getName();

    public abstract void setName(ActorProxy name);

    public abstract String getMessage();

    public abstract void setMessage(String message);

    public Event getEvent (){
        return event;
    }

    public void setEvent(Event event){
        this.event = event;
    }


}
