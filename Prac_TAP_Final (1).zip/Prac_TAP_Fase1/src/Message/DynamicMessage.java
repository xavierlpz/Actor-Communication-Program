package Message;

import Actors.ActorProxy;

import java.lang.reflect.Method;

public class DynamicMessage extends Message{
    ActorProxy actor;
    String nameMethod;
    Method method;
    Object [] args;

    public DynamicMessage(ActorProxy actor, String nameMethod, Method method, Object[] args) {
        this.actor = actor;
        this.nameMethod = nameMethod;
        this.method = method;
        this.args = args;
    }

    public ActorProxy getActor() {
        return actor;
    }

    public String getNameMethod() {
        return nameMethod;
    }

    public Method getMethod() {
        return method;
    }

    public Object[] getArgs() {
        return args;
    }

    @Override
    public ActorProxy getName() {
        return actor;
    }

    @Override
    public void setName(ActorProxy name) {
        this.actor = name;
    }

    @Override
    public String getMessage() {
        return null;
    }

    @Override
    public void setMessage(String message) {

    }


}
