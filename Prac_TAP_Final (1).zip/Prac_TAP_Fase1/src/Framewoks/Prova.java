package Framewoks;

import Observer.Panel;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class Prova extends JFrame {
    private JPanel panel1;
    private JButton create;
    private JComboBox comboBox1;
    private JProgressBar progressBar;
    private JButton AddMessage;
    private JLabel numberMsg;
    private JPanel central;
    private Control control;
    private JTextArea receivedMsg = new JTextArea();
    private JTextArea sentMsg = new JTextArea();
    private JPanel panelSentMsg;
    private JPanel panelReceivedMsg;
    private int numActors = 3;
    private String actorAttached = "1";
    private Panel actorListener = new Panel(actorAttached);

    public JTextArea getSentMsg() {
        return sentMsg;
    }

    public JLabel getNumberMsg() {
        return numberMsg;
    }

    public String getActorAttached() {
        return actorAttached;
    }

    public JTextArea getReceivedMsg() {
        return receivedMsg;
    }

    public JProgressBar getProgressBar() {
        return progressBar;
    }

    public Prova(Control control) {
        super("Actor System User Interface");
        setContentPane(panel1);
        this.control = control;
        create.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               control.createActor();
            }
        });

        comboBox1.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                super.focusGained(e);

                ArrayList<Integer> listNumbers = control.getListActors();

                String item;
                String name;
                for (int i = 0; i < listNumbers.size(); i++){
                    item = "Actor " + listNumbers.get(i);
                    name = String.valueOf(listNumbers.get(i));
                    if (comboBox1.getItemAt(i) ==null){
                        comboBox1.addItem(item);
                        control.attach(name);
                        actorAttached = name;
                    }
                }
            }
        });
        comboBox1.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                String nameActor = comboBox1.getSelectedItem().toString();
                String[] listNames = nameActor.split(" ");
                control.attach(listNames[1]);
                actorAttached = listNames[1];
            }
        });

        AddMessage.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                control.sendMessage();
            }
        });
    }

    public void createUIComponents() {
        JScrollPane scroll1, scroll2;
        panelReceivedMsg = new JPanel();
        panelReceivedMsg.setLayout(new FlowLayout());
        panelReceivedMsg.add(new JLabel("Received Messages Log:"));
        scroll1 = new JScrollPane(receivedMsg);
        receivedMsg.setRows(50);
        receivedMsg.setColumns(30);
        scroll1.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        panelReceivedMsg.add(scroll1);
        central.add(panelReceivedMsg,BorderLayout.WEST);

        panelSentMsg = new JPanel();
        panelSentMsg.setLayout(new FlowLayout());
        panelSentMsg.add(new JLabel("Sent Messages Log:"));
        scroll2 = new JScrollPane(sentMsg);
        sentMsg.setRows(50);
        sentMsg.setColumns(30);
        scroll2.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        panelSentMsg.add(scroll2);
        central.add(panelSentMsg,BorderLayout.EAST);

    }
}
