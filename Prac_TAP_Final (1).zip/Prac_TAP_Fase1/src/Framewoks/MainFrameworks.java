package Framewoks;
import Actors.ActorContext;
import Actors.ActorProxy;
import Actors.RingActor;
import Decorators.NotifyDecorator;
import Message.AddActorMessage;
import Observer.MonitorService;
import Observer.Panel;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.HashSet;

public class MainFrameworks extends Thread{


    public static void main (String[] args) {

        Control control = new Control();
        control.inicialization();
        Prova prova = new Prova(control);
        prova.createUIComponents();
        Task progress = new Task(prova, control);
        progress.progressBar();
        prova.setSize (600,600);
        prova.setVisible(true);
    }
}
