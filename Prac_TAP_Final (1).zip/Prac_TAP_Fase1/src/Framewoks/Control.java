package Framewoks;

import Actors.Actor;
import Actors.ActorContext;
import Actors.ActorProxy;
import Actors.RingActor;
import Decorators.NotifyDecorator;
import Message.AddActorMessage;
import Message.GetInsultMessage;
import Observer.ActorListener;
import Observer.MonitorService;
import Observer.Panel;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;

public class Control {
    private int numAc ;
    private MonitorService monitor;
    private ActorContext context;

   public Control() {
       numAc = 3;
       context = ActorContext.getInstance();
       this.monitor = new MonitorService();
   }

    public void inicialization (){
        int i = 2;

        ActorProxy ac1 = context.spawnActor("1", new NotifyDecorator(new RingActor("1", null, monitor), monitor));
        ac1.sendMessage(new AddActorMessage(ac1, String.valueOf(i)));
    }
   public void createActor(){
        ActorProxy ac1 = context.lookup("1");
        ac1.sendMessage(new AddActorMessage(ac1, String.valueOf(numAc)));
        numAc++;
    }
    public void sendMessage(){
        ActorProxy ac1 = context.lookup("1");
        ac1.sendMessage(new GetInsultMessage(ac1,"Activated"));
    }

    public HashMap<String, HashSet<String>> getTrafic (){
        return monitor.getTraffic();
    }

    public ArrayList<Integer> getListActors (){
        ActorContext context = ActorContext.getInstance();
        ArrayList<Actor> listActors = context.getAll();
        ArrayList<Integer> listNumbers = new ArrayList<Integer> ();

        for (int i =0; i < listActors.size(); i++) {
            listNumbers.add(Integer.valueOf(listActors.get(i).getNameActor()));
        }
        listNumbers.sort(Comparator.naturalOrder());
        return listNumbers;
    }

    public void attach (String name){
        ActorListener actorListener = new Panel(name);
        monitor.attach(name,actorListener);
    }

    public ArrayList<String> getReceivedMessages (String nameActor) {
        HashMap<String, ArrayList<String>> received;
        ActorProxy actor;
        ArrayList<String> list1 = null;
        int number;

        actor = context.lookup(nameActor);
        if (actor != null) {
            received = monitor.getReceivedMessages();
            list1 = received.get(nameActor);
        }
        return list1;
    }

    public ArrayList<String> getSentMessages (String nameActor) {
        HashMap<String, ArrayList<String>> sent;
        ActorProxy actor;
        ArrayList<String> list1 = null;
        int number;

        actor = context.lookup(nameActor);
        if (actor != null) {
            sent = monitor.getSentMessages();
            list1 = sent.get(nameActor);
        }
        return list1;
    }

    public int getNumberOfMessages (String actor){
        return monitor.getNumberofMessages(context.lookup(actor));
    }

}
