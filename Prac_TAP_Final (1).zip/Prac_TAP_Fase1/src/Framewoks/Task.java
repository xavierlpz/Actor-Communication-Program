package Framewoks;

import Actors.ActorContext;
import Actors.ActorProxy;
import Observer.MonitorService;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

public class Task extends Thread {

    private JProgressBar progressBar;
    private Prova prova;
    private String nameActor;
    private JLabel numberMsg;
    private Control control;

    private JTextArea receivedMsg, sentMsg;

    public Task (Prova prova, Control control) {
        this.prova = prova;
        this.control = control;
        this.progressBar = prova.getProgressBar();
        this.numberMsg = prova.getNumberMsg();
        this.receivedMsg = prova.getReceivedMsg();
        this.sentMsg = prova.getSentMsg();
    }

    public void progressBar () {
        this.start();
    }

    public void run () {

        HashMap<String, HashSet<String>> map;
        HashSet<String> low;
        HashSet<String> medium;
        HashSet<String> high;
        ArrayList<String> list1;
        ArrayList<String> list2;
        int number;
        int progress = 0;
        String aux = "";

        while (true) {
            nameActor = prova.getActorAttached();
            number = control.getNumberOfMessages(nameActor);
            numberMsg.setText(String.valueOf(number));

            list1 = control.getReceivedMessages(nameActor);
            if (list1 != null) {
                list1 = (ArrayList<String>)list1.clone();
                for (String i : list1)
                    aux = aux + i + "\n";
                  receivedMsg.setText(aux);
                    aux = "";

            }


            list2 = control.getSentMessages(nameActor);
            if (list2 != null) {
                list2 = (ArrayList<String>)list2.clone();
                for (String i : list2)
                    aux = aux + i + "\n";
                sentMsg.setText(aux);
                aux = "";
            }


            map = control.getTrafic();
            low = map.get("LOW");
            medium = map.get("MEDIUM");
            high = map.get("HIGH");
            if (low != null ) {
                if (low.size() != 0)
                    progress = 33;

            }
            if (medium != null ) {
                if (medium.size() != 0)
                    progress = 66;

            }
            if (high != null ) {
                if (high.size() != 0)
                    progress = 100;

            }

            progressBar.setValue(progress);
            try {
                sleep(500);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
