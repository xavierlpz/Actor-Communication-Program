package Test;
import Actors.Actor;
import Actors.ActorContext;
import Actors.ActorProxy;
import Actors.InsultActor;
import Observer.MonitorService;
import org.junit.Assert;
import org.junit.Test;
import java.util.ArrayList;


public class ActorContextTest {

    ActorContext context = ActorContext.getInstance();
    MonitorService monitor = new MonitorService();
    ActorProxy ac1 = context.spawnActor("1",new InsultActor("1", monitor));
    ActorProxy ac2 = context.spawnActor("2",new InsultActor("2", monitor));
    ActorProxy ac3 = context.spawnActor("3",new InsultActor("3", monitor));

    @Test
    public void testSpawnActor() {
        String theoric [] = {ac1.getNameActor(), ac2.getNameActor(), ac3.getNameActor()};
        ArrayList<Actor> actors = context.getAll();
        String actual [] = {actors.get(0).getNameActor(), actors.get(1).getNameActor(), actors.get(2).getNameActor()};
        Assert.assertArrayEquals(theoric, actual);
    }

    @Test
    public void testLookup() {
       Assert.assertEquals(ac1.getNameActor(),context.lookup("1").getNameActor());
    }

}
