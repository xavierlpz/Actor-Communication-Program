package Test;


import Actors.*;
import Decorators.EncryptionDecorator;
import Decorators.NotifyDecorator;
import Dynamic.DynamicProxy;
import Dynamic.InsultService;
import Dynamic.InsultServiceImp;
import Message.*;
import Observer.MonitorService;
import Observer.Panel;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;

import static java.lang.Thread.sleep;

public class MainTest {
    public static void main(String[] args) throws InterruptedException {
        Scanner entrada = new Scanner(System.in);
        int option;
        boolean escape = false;
        int rounds= 0;
        ActorContext context = ActorContext.getInstance();
        MonitorService monitor = new MonitorService();
        ActorProxy ac1 = context.spawnActor("1", new PerformanceActor("1", null, monitor));

        rounds = 0;
        for (int i = 2; i <= 100; i++) {
            ac1.sendMessage(new AddActorMessage(ac1, String.valueOf(i)));
            sleep(2);
        }
        System.out.println("Waiting the 100 rounds");
        for (int i = 2; i <= 100000; i++) {
            ac1.sendMessage(new GetInsultMessage(ac1,"start"));
            sleep(2);
        }
        System.out.println("Waiting the 100 rounds");

        /*System.out.println("Waiting the 100 rounds");
        ac1.sendMessage(new GetInsultMessage(null, "Proxy"));
        double ini = System.currentTimeMillis();
        while (rounds != 100) {
            ac1.receive();
            rounds++;
        }

        double end = System.currentTimeMillis();
        double time = (double) ((end - ini) / 1000);
        System.out.println("the message has taken " + time + " seconds");*/



        /*
        Scanner entrada = new Scanner(System.in);
        ActorContext context = ActorContext.getInstance();


        MonitorService observer = new MonitorService();
        Panel p = new Panel("ping");
        observer.attach("ping",p);

        ActorProxy ac1 = context.spawnActor("ping",new NotifyDecorator(new InsultActorPrint("ping"),observer));
        ActorProxy ac2 = context.spawnActor("pong",new NotifyDecorator(new InsultActorPrint("pong"),observer));

        ac1.sendMessage(new GetInsultMessage(ac2,"start"));
        */

/*
        for(int i = 0; i < 19; i++){
            ac1.sendMessage(new GetInsultMessage(ac2,"start"));
        }
        ac2.sendMessage(new QuitMessage(ac1));*/
/*
        try {
            sleep(3000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        ac1.sendMessage(new ErrorMessage(ac2));

        try {
            sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        System.out.println(observer.getEvents());*/
       // System.out.println(observer.getNumberofMessages(ac1));
/*
        HashMap<String, HashSet<String>> map = observer.getTraffic();
        HashSet<String> low = map.get("LOW");
        HashSet<String> medium = map.get("MEDIUM");
        HashSet<String> high = map.get("HIGH");
        System.out.println("Actors LOW:");
        if (low != null) {
            for (String i : low)
                System.out.println(i.toString());
        }

        System.out.println("Actors MEDIUM:");
        if (medium != null) {
            for (String i : medium)
                System.out.println(i.toString());
        }
        System.out.println("Actors HIGH:");
        if (high != null) {
            for (String i : high)
                System.out.println(i.toString());
        }*/

/*
        ActorProxy insult = context.spawnActor("1", new DynamicActor("1", new InsultServiceImp()));
        InsultService insulter = (InsultService) DynamicProxy.newInstance(new InsultServiceImp(), insult);

        insulter.addInsult("puta madre");
        System.out.println(insulter.getInsult());
        System.out.println(insulter.getAllInsult());
*/

       /* ActorProxy insult = context.spawnActor("1",new InsultActorPrint("1"));
        insult.sendMessage(new GetInsultMessage(null, "message"));
        Message result = insult.receive();
        System.out.println(result.getMessage());*/

        /*ActorProxy ac1 = context.spawnActor("1", new EncryptionDecorator(new InsultActorPrint("1")));
        ActorProxy ac2 = context.spawnActor("2", new EncryptionDecorator(new InsultActorPrint("2")));*/

       /* ActorProxy ac1 = context.spawnActor("1",new InsultActorPrint("1"));
        ActorProxy ac2 = context.spawnActor("2",new InsultActorPrint("2"));*/

        //ac1.sendMessage(new GetInsultMessage(ac2, "Control"));

    }
}
