package Test;

import Actors.ActorContext;
import Actors.ActorProxy;
import Actors.PerformanceActor;
import Message.AddActorMessage;
import Message.GetInsultMessage;
import Observer.MonitorService;

import static java.lang.Thread.sleep;

public class PerformanceTest {

    public static void main (String [] args) {
        ActorContext context = ActorContext.getInstance();
        MonitorService monitor = new MonitorService();
        ActorProxy ac1 = context.spawnActor("1", new PerformanceActor("1", null, monitor));
        int rounds = 0;
        for (int i = 2; i <= 100; i++) {
            ac1.sendMessage(new AddActorMessage(ac1, String.valueOf(i)));
            try {
                sleep(2);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        System.out.println("Waiting the 100 rounds");
        ac1.sendMessage(new GetInsultMessage(null, "Proxy"));
        double ini = System.currentTimeMillis();
        while (rounds != 100) {
            System.out.println("Round: " + rounds);
            ac1.receive();
            rounds++;
        }

        double end = System.currentTimeMillis();
        double time = (double) ((end - ini) / 1000);
        System.out.println("the message has taken " + time + " seconds");
        int numMessages = 10000;
        for (int i = 2; i <= numMessages; i++) {
            ac1.sendMessage(new GetInsultMessage(ac1,"start"));
            try {
                sleep(2);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        System.out.println("The Actor System can process "+numMessages);
    }

}
