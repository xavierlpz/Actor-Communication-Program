package Test;

import Actors.*;
import Message.AddInsultMessage;
import Message.GetAllInsultsMessage;
import Message.GetInsultMessage;
import Message.QuitMessage;
import Observer.MonitorService;
import org.junit.Assert;
import org.junit.Test;
import java.util.List;
import static java.lang.Thread.sleep;

public class InsultActorTest {
    public static boolean quit;
    ActorContext context = ActorContext.getInstance();
    MonitorService monitor = new MonitorService();
    ActorProxy ac1 = context.spawnActor("1",new InsultActorPrint("1", monitor));
    ActorProxy ac2 = context.spawnActor("2",new InsultActorPrint("2", monitor));


    @Test
    public void testQuitMessage()  {
        quit = false;
        ac1.sendMessage(new QuitMessage(ac2));
        try {
            sleep(3000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        Assert.assertTrue(quit);

    }

    @Test
    public void testGetInsultMessage()
    {
        boolean functional = false;
        ac2.sendMessage(new GetInsultMessage(null,"start"));
        String insult = ac2.receive().getMessage();
        if (insult.equals("Dumb") || insult.equals("Fuck") || insult.equals("Bastard") || insult.equals("Bitch") || insult.equals("Shit"))
            functional = true;
        Assert.assertTrue(functional);
    }

    @Test
    public void testAddInsultMessage()
    {
        boolean accomplish = false;
        String newInsult = "Idiot";
        ac2.sendMessage(new AddInsultMessage(ac1,newInsult));
        try {
            sleep(3000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        ac2.sendMessage(new GetAllInsultsMessage(null));
       String insults = ac2.receive().getMessage();
       if (insults.endsWith(newInsult+"]")) accomplish = true;
        Assert.assertTrue(accomplish);
    }

    @Test
    public void testGetAllInsultMessage()
    {
        List<String> insults = List.of("Fuck", "Dumb", "Bastard", "Bitch", "Shit");
        String expected = insults.toString();
        ac2.sendMessage(new GetAllInsultsMessage(null));
        String actual = ac2.receive().getMessage();
        Assert.assertEquals(expected, actual);
    }

}