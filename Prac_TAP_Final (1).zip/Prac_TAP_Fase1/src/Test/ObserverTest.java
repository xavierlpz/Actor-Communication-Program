package Test;

import Actors.ActorContext;
import Actors.ActorProxy;
import Actors.InsultActor;
import Decorators.NotifyDecorator;
import Message.DoNothingMessage;
import Message.GetInsultMessage;
import Observer.MonitorService;
import Observer.Panel;
import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import static java.lang.Thread.sleep;

public class ObserverTest {

    ActorContext context = ActorContext.getInstance();
    MonitorService monitor = new MonitorService();
    ActorProxy ac1 = context.spawnActor("1",new NotifyDecorator(new InsultActor("1", monitor),monitor));
    ActorProxy ac2 = context.spawnActor("2",new NotifyDecorator(new InsultActor("2", monitor),monitor));

    @Test
    public void getSentMessagesTest() {
        boolean functional = false;
        List<String> expected = List.of("potato","tomato","salad");
       Panel p = new Panel("2");
       monitor.attach("2", p);
       ac1.sendMessage(new DoNothingMessage(ac2, "potato"));
       ac1.sendMessage(new DoNothingMessage(ac2, "tomato"));
       ac1.sendMessage(new DoNothingMessage(ac2, "salad"));
       ArrayList<String> sentLog = monitor.getSentMessages().get("2");
       for (int i = 0; i < expected.size(); i++) {
           if (sentLog.get(i).startsWith(expected.get(i)))
               functional = true;
           else
               functional = false;
           Assert.assertTrue(functional);
       }

    }

    @Test
    public void getReceivedMessagesTest() {
        boolean functional = false;
        List<String> expected = List.of("potato","tomato","salad");
        Panel p = new Panel("1");
        monitor.attach("1", p);
        ac1.sendMessage(new DoNothingMessage(ac2, "potato"));
        ac1.sendMessage(new DoNothingMessage(ac2, "tomato"));
        ac1.sendMessage(new DoNothingMessage(ac2, "salad"));
        try {
            sleep(3000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        ArrayList<String> receivedLog = monitor.getReceivedMessages().get("1");
        for (int i = 0; i < expected.size(); i++) {
            if (receivedLog.get(i).startsWith(expected.get(i)))
                functional = true;
            else
                functional = false;
            Assert.assertTrue(functional);
        }


    }

    @Test
    public void getTrafficTest() {
        Panel p = new Panel("1");
        monitor.attach("1", p);
        for (int i = 0; i < 2; i++)
            ac1.sendMessage(new GetInsultMessage(ac2, "potato"));
        try {
            sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        HashSet<String> expected = new HashSet<>();
        expected.add("1");
        HashSet<String> actor = monitor.getTraffic().get("LOW");
        Assert.assertEquals(actor, expected);

        for (int i = 0; i < 7; i++)
            ac1.sendMessage(new GetInsultMessage(ac2, "potato"));
        try {
            sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        actor = monitor.getTraffic().get("MEDIUM");
        Assert.assertEquals(actor, expected);

        for (int i = 0; i < 17; i++)
            ac1.sendMessage(new GetInsultMessage(ac2, "potato"));
        try {
            sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        actor = monitor.getTraffic().get("HIGH");
        Assert.assertEquals(actor, expected);

    }

    @Test
    public void getNumberOfMessagesTest() {
        Panel p = new Panel("1");
        monitor.attach("1", p);
        int expected = 5;
        for (int i = 0; i < expected; i++)
            ac1.sendMessage(new DoNothingMessage(ac2, "potato"));
        try {
            sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        int actual = monitor.getNumberofMessages(context.lookup("1"));
        Assert.assertEquals(expected, actual);

    }
}
