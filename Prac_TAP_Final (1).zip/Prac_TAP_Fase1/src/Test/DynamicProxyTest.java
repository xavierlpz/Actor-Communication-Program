package Test;
import Actors.ActorContext;
import Actors.ActorProxy;
import Actors.DynamicActor;
import Actors.InsultActor;
import Decorators.FirewallDecorator;
import Dynamic.DynamicProxy;
import Dynamic.InsultService;
import Dynamic.InsultServiceImp;
import Observer.MonitorService;
import org.junit.Assert;
import org.junit.Test;
import java.util.List;
import static java.lang.Thread.sleep;

public class DynamicProxyTest {
    boolean functional;
    ActorContext context = ActorContext.getInstance();
    MonitorService monitor = new MonitorService();
    ActorProxy ac1 = context.spawnActor("1",new FirewallDecorator(new InsultActor("1", monitor)));
    ActorProxy insult = context.spawnActor("1", new DynamicActor("1", new InsultServiceImp()));
    InsultService insulter = (InsultService) DynamicProxy.newInstance(new InsultServiceImp(), insult);

    @Test
    public void getInsultTest() {
        functional = false;
       String insult = insulter.getInsult();
        if (insult.equals("Dumb") || insult.equals("Fuck") || insult.equals("Bastard") || insult.equals("Bitch") || insult.equals("Shit"))
            functional = true;
        Assert.assertTrue(functional);

    }
    @Test
    public void getAllInsultTest() {
        List<String> insults = List.of("Fuck", "Dumb", "Bastard", "Bitch", "Shit");
        String expected = insults.toString();
        String actual = insulter.getAllInsult();

        Assert.assertEquals(expected, actual);
    }
    @Test
    public void addInsultTest() {
        boolean accomplish = false;
        String newInsult = "Idiot";
        insulter.addInsult(newInsult);
        try {
            sleep(3000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        String insults = insulter.getAllInsult();

        if (insults.endsWith(newInsult+"]")) accomplish = true;
        Assert.assertTrue(accomplish);
    }
}
