package Test;
import Actors.ActorContext;
import Actors.ActorProxy;
import Actors.InsultActor;
import Decorators.EncryptionDecorator;
import Decorators.FirewallDecorator;
import Decorators.LambdaFirewallDecorator;
import Message.AddClosureMessage;
import Message.GetInsultMessage;
import Observer.MonitorService;
import org.junit.Assert;
import org.junit.Test;

public class DecoratorsTest {
    public static boolean enable;
    ActorContext context = ActorContext.getInstance();
    MonitorService monitor = new MonitorService();
    ActorProxy ac1 = context.spawnActor("1",new FirewallDecorator(new InsultActor("1", monitor)));
    ActorProxy ac2 = context.spawnActor("2",new LambdaFirewallDecorator<String>(new InsultActor("2", monitor)));
    ActorProxy ac3 = context.spawnActor("3",new EncryptionDecorator(new InsultActor("3", monitor)));
    ActorProxy ac4 = context.spawnActor("3",new EncryptionDecorator(new FirewallDecorator(new InsultActor("3", monitor))));


    @Test
    public void testEncryptionDecorator() {
        boolean functional = false;
        ac3.sendMessage(new GetInsultMessage(null,"start"));
        String insult = ac3.receive().getMessage();
        if (insult.equals("Dumb") || insult.equals("Fuck") || insult.equals("Bastard") || insult.equals("Bitch") || insult.equals("Shit"))
            functional = true;
        Assert.assertTrue(functional);

    }

    @Test
    public void testFirewallDecorator() {
        String unregisteredName = "Intruder";
        enable = true;
        ac1.sendMessage(new GetInsultMessage(new ActorProxy(unregisteredName, new InsultActor(unregisteredName, monitor)), "Firewall"));
        Assert.assertFalse(enable);
    }

    @Test
    public void testLambdaDecorator() {
        enable = true;
        ac2.sendMessage(new AddClosureMessage<>(ac2, "Penguin", (String s) -> { return (s.equals("start") || s.equals("initialize") || s.equals("begin"));}));
        Assert.assertFalse(enable);
    }

    @Test
    public void testEncryptionFirewallDecorator() {
        boolean functional = false;
        String unregisteredName = "Intruder";
        enable = true;
        ac4.sendMessage(new GetInsultMessage(new ActorProxy(unregisteredName, new InsultActor(unregisteredName, monitor)), "Firewall"));
        ac4.sendMessage(new GetInsultMessage(null,"start"));
        String insult = ac4.receive().getMessage();
        if (insult.equals("Dumb") || insult.equals("Fuck") || insult.equals("Bastard") || insult.equals("Bitch") || insult.equals("Shit"))
            functional = true;
        Assert.assertFalse(enable);
        Assert.assertTrue(functional);
    }
}
