package Dynamic;

import Actors.ActorProxy;

public interface InsultService {
    void addInsult(String insult);
    String getInsult();
    String getAllInsult();
}
