package Dynamic;

import Actors.ActorProxy;
import Message.*;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;


public class DynamicProxy implements InvocationHandler{
    private Object target = null;
    private ActorProxy actor;

    public static Object newInstance(Object target, ActorProxy actor){

        Class targetClass = target.getClass();
        Class interfaces[] = targetClass.getInterfaces();
        return Proxy. newProxyInstance(targetClass.getClassLoader(),
                interfaces, new DynamicProxy(target, actor));
    }
    private DynamicProxy(Object target, ActorProxy actor) {
        this.target = target;
        this.actor = actor;
    }

    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable{
        Object invocationResult = null;
        try
        {
            actor.sendMessage(new DynamicMessage(null, method.getName(), method, args));
            if(!method.getReturnType().getName().equals("void")){
                invocationResult = actor.receive().getMessage();
            }
        }
        catch(Exception e)
        {
            System.err.println("Invocation of " + method.getName() + " failed");
        }
        finally{
            return invocationResult;
        }
    }

}
