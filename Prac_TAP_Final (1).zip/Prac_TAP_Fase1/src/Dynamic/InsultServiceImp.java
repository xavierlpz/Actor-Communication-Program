package Dynamic;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

public class InsultServiceImp implements InsultService{

    private List<String> listInsults;

    private final String [] listPred = new String[]{"Fuck", "Dumb", "Bastard", "Bitch", "Shit"};

    /**
     * Builder of InsultServiceImp class.
     * Generates a list of 5 insults.
     */
    public InsultServiceImp() {
        listInsults = new LinkedList<String>();
        for(int i = 0; i < listPred.length; i++){
            listInsults.add(listPred[i]);
        }
    }

    /**
     * Adds the insult passed by parameter to the list of insults
     * @param insult the insult to add in the list
     */
    @Override
    public void addInsult(String insult) {
        listInsults.add(insult);
    }

    /**
     * Returns a random insult of a list of insults
     * @return a string of the insult
     */
    @Override
    public String getInsult() {
        String randInsult;
        Random rand;
        int randPosInsult;

        rand = new Random();
        randPosInsult = rand.nextInt(listInsults.size());
        randInsult = listInsults.get(randPosInsult);
       return  randInsult;
    }

    /**
     * Return all the insults of the list f insults
     * @return a string with all the insults
     */
    @Override
    public String getAllInsult() {
        return listInsults.toString();
    }

}
