package Actors;

import Message.*;
import java.util.*;
import Observer.*;
import static java.lang.Thread.sleep;

public class InsultActorPrint implements Actor {
    private Queue <Message> readBuffer;
    private String name;

    private List<String> listInsults;
    private final String [] listPred = new String[]{"Fuck", "Dumb", "Bastard", "Bitch", "Shit"};

    /**
     * Builder of the InsultActorPrint class, it also notifies to the MonitorService that an actor
     * has been created.
     * @param name the name of the actor
     */
    public InsultActorPrint(String  name, MonitorService monitor){
        this.name = name;
        readBuffer = new LinkedList<Message>();
        listInsults = new LinkedList<String>();
        for(int i = 0; i < listPred.length; i++){
            listInsults.add(listPred[i]);
        }
        Message message =new CreateMessage(null);
        message.setEvent(Event.CREATED);
        monitor.notify(message,this);
    }

    /**
     * Adds a message to its own messages queue
     * @param message the message to be added
     */
    public void sendMessage(Message message) {
        readBuffer.add(message);
    }

    /**
     * Returns the instance of the actor
     * @return an instance of the actor
     */
    public Actor getActor() {
        return this;
    }

    /**
     * Returns the name of the actor
     * @return a string with the name of the actor
     */
    public String getNameActor() {
        return name;
    }

    /**
     * Returns the messages queue of the actor
     * @return a messages queue
     */
    public Queue<Message> getQueue() {
        return readBuffer;
    }

    /**
     * Retrieves and removes the head of its messages queue
     * @return a message of the buffer messages
     */
    @Override
    public Message getMessage() {
        return readBuffer.poll();
    }

    /**
     * Processes the message passed by parameter, depending on the type of message it does a certain action
     * @param message the message to be processed
     */
    @Override
    public void processMessage(Message message) {
        String msg, randInsult;
        ActorProxy name;

        Random rand;
        int randPosInsult;
        ActorContext context = ActorContext.getInstance();

        msg = message.getMessage();
        name = message.getName();

        if (message instanceof GetInsultMessage || message instanceof AddClosureMessage) {
            rand = new Random();
            randPosInsult = rand.nextInt(listInsults.size());
            randInsult = listInsults.get(randPosInsult);
            System.out.println("(" + this.name + ")" + " receive " + msg +"\n");
            System.out.println("(" + this.name + ")" + " send " +  randInsult + " to actor " + name.getNameActor());
            message = new GetInsultMessage(context.lookup(this.name), randInsult);
            name.sendMessage(message);
        }

        if (message instanceof AddInsultMessage) {
            listInsults.add(msg);
            System.out.println("(" + this.name + ")" + " add " + msg);
        }
        if (message instanceof GetAllInsultsMessage) {
            System.out.println("(" + this.name + ")" + "has the following insults: ");
            message.setMessage(listInsults.toString());
            name.sendMessage(message);
            System.out.println(listInsults.toString());
        }
        try {
            sleep (2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }




}