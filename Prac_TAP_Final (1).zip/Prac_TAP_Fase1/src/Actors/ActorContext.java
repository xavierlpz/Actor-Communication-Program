package Actors;

import Message.CreateMessage;
import Message.Message;
import Observer.ActorListener;
import Observer.MonitorService;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Set;

public class ActorContext {
    private static ActorContext actorcontext = new ActorContext();
    private HashMap<String, ActorValues> listActors;

    /**
     * Builder of the ActorContext class.
     */
    private ActorContext(){
        listActors = new HashMap <String, ActorValues> ();
    }

    /**
     * Returns the instance of the ActorContext (Singleton Pattern).
     * @return an instance of the ActorContext
     */
    public static ActorContext getInstance(){ return actorcontext;}

    /**
     * Introduces an actor into the HashMap of ActorValues [Actor,name] and starts its execution.
     *
     * @param name the name of the actor
     * @param actor the instance of the actor
     * @return an actor proxy of the actor passed by parameter
     */
    public ActorProxy spawnActor(String name, Actor actor){
        ActorValues aux = new ActorValues(actor, name);
        listActors.put(name,aux);
        ActorThread ac = new ActorThread(actor);
        ActorProxy proxyActor = new ActorProxy(name, actor);
        return proxyActor;
    }

    /**
     * Returns an actor proxy of the actor that corresponds to the name passed
     * by parameter, or null if it doesn't correspond to any actor of the ActorContext.
     *
     * @param name the name of the actor
     * @return an actor proxy
     */
    public ActorProxy lookup(String name){

        ActorValues aux = listActors.get(name);
        if(aux != null){
            ActorProxy proxyActor = new ActorProxy(name, aux.getActor());
            return proxyActor;
        }
        return null;
    }

    /**
     * Returns a string that contains the name of all the actors of the ActorContext.
     *
     * @return a string of names
     */
    public String getNames() {
        return "ActorContext{" +
                "AContextName=" + listActors.keySet() +
                '}';
    }

    /**
     * Returns an ArrayList with all the actors of the ActorContext.
     *
     * @return an ArrayList of Actors
     */
    public ArrayList<Actor> getAll(){

        ArrayList<Actor> aux = new ArrayList<>();
        Set<String> keys = listActors.keySet();
        for (String key: keys) {
            aux.add(listActors.get(key).getActor());
        }

        return aux;
    }
}