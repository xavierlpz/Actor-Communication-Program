package Actors;

import Message.*;
import Test.ActorContextTest;
import Test.InsultActorTest;

public class ActorThread extends Thread{

    private Actor actor;
    private boolean quit = false;

    public boolean isQuit() {
        return quit;
    }

    /**
     * Builder of the ActorThread class.
     * @param actor the instance of an actor
     */
    public ActorThread(Actor actor) {
        this.actor = actor;
        this.start();
    }

    /**
     * Thread of the actor that reads a message of its queue and executes the processMessage method of the
     * actor (or Decorator) that contains the ActorThread class. It finishes when a QuitMessage or an ErrorMessage is received.
     */
    public void run(){
        Message mensaje;

        while(!quit) {
            mensaje = actor.getMessage();
            if (mensaje != null) {
                actor.processMessage(mensaje);
                if (mensaje instanceof QuitMessage || mensaje instanceof ErrorMessage)
                {
                    quit = true;
                    InsultActorTest.quit = true;
                }

            }
            try {
                sleep (1);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
