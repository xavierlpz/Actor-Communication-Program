package Actors;

public class ActorValues {
    private Actor actor;
    private String name;

    /**
     * Builder of the ActorValues class
     * @param actor an instance of the actor to be saved
     * @param name the name of the actor
     */
    public ActorValues (Actor actor, String name) {
        this.actor = actor;
        this.name = name;
    }


    public Actor getActor() {
        return actor;
    }

    public String getName() {
        return name;
    }

}
