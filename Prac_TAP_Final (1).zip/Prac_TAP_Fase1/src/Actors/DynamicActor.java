package Actors;

import Message.*;
import java.util.LinkedList;
import java.util.Queue;

public class DynamicActor implements Actor{
    private Queue <Message> readBuffer;
    private String name;
    private Object object;

    /**
     * Builder of the DynamicActor class.
     * @param name the name of the DynamicActor
     * @param object instance of the class to invoke
     */
    public DynamicActor(String  name, Object object){
        this.name = name;
        readBuffer = new LinkedList<Message>();
        this.object = object;
    }

    /**
     * Adds a message to its own messages queue
     * @param message the message to be added
     */
    @Override
    public void sendMessage(Message message) {
        readBuffer.add(message);
    }

    /**
     * Returns the instance of the actor
     * @return an instance of the actor
     */
    @Override
    public Actor getActor() {
        return this;
    }

    /**
     * Returns the name of the actor
     * @return a string with the name of the actor
     */
    @Override
    public String getNameActor() {
        return name;
    }

    /**
     * Returns the messages queue of the actor
     * @return a messages queue
     */
    public Queue<Message> getQueue() {
        return readBuffer;
    }

    /**
     * Retrieves and removes the head of its messages queue
     * @return a message of the buffer messages
     */
    @Override
    public Message getMessage() {
        return readBuffer.poll();
    }

    /**
     * Invokes the method that has the DynamicMessage and that is implemented by the instance
     * contained in the attribute "object", with its parameters. Also sends a message with the
     * result of the method (if is not void) to the ActorProxy that sent the DynamicMessage.
     * @param message
     */
    @Override
    public void processMessage(Message message)  {
       DynamicMessage msg = (DynamicMessage) message;

       try {
           Object result = msg.getMethod().invoke(object, msg.getArgs());
           if(result != null){
               msg.getActor().sendMessage(new GetInsultMessage(null, (String) result));
           }
       } catch (Throwable e){
           e.getMessage();
       }

    }
}
