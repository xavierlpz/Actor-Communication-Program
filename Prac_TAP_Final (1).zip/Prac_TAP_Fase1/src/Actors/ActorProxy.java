package Actors;

import Message.Message;
import java.util.LinkedList;
import java.util.Queue;

import static java.lang.Thread.sleep;

public class ActorProxy implements Actor {
    private Queue <Message> readBuffer;
    private Actor actor;
    private String name;

    /**
     * Builder of the ActorProxy class.
     * @param name the name of the intercepted actor
     * @param actor the instance of the intercepted actor
     */

    public ActorProxy(String name, Actor actor){
        this.name = name;
        this.actor = actor;
        readBuffer = new LinkedList<Message>();
    }

    /**
     * Returns the actor intercepted by the ActorProxy (it may be a type of actor or a decorator).
     * @return an instance of an actor
     */
    public Actor getActor() {
        return actor;
    }

    /**
     * Returns the name of the actor intercepted by the ActorProxy.
     * @return a string with the name of the actor
     */
    @Override
    public String getNameActor() {
        return name;
    }

    @Override
    public Queue<Message> getQueue() {
        return null;
    }

    @Override
    public Message getMessage() {
        return null;
    }


    @Override
    public void processMessage(Message message) {

    }

    /**
     * Waits until the ActorProxy receives a message on its own buffer and returns it.
     * @return a message of the messages buffer
     */
    public Message receive ()  {
        Message message;
         while(true){
            if(!readBuffer.isEmpty()) {
                message = readBuffer.poll();
                return message;
            }
             try {
                 sleep(1);
             } catch (InterruptedException e) {
                 throw new RuntimeException(e);
             }
         }
    }

    /**
     * Adds a message to the messages buffer of the ActorProxy (only called by a RespondProxy).
     * @param message the message to add
     */
    protected void send(Message message){
        readBuffer.add(message);
    }

    /**
     * Sends a message to the actor intercepted by the ActorProxy, or to a new RespondProxy if
     * the sender of the message is null.
     * @param message the message to be sent
     */
    @Override
    public void sendMessage(Message message) {
        if (message.getName() == null){
            message.setName(new RespondProxy(this));
        }
        if(actor != null){
            actor.sendMessage(message);
        }

    }
}
