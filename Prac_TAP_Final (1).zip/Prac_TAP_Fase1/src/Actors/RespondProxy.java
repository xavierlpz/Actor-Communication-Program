package Actors;

import Message.Message;
import java.util.Queue;

public class RespondProxy extends ActorProxy {

    private ActorProxy actor;

    /**
     * Builder of RespondProxy class
     * @param actor the ActorProxy to be intercepted
     */
    public RespondProxy(ActorProxy actor){
        super(actor.getNameActor(), actor.getActor());
        this.actor = actor;
    }

    /**
     * Returns the intercepted ActorProxy
     * @return an instance of the ActorProxy
     */
    public Actor getActor() {
        return actor;
    }

    /**
     * Returns the name of the intercepted ActorProxy
     * @return a string with the name of an ActorProxy
     */

    @Override
    public String getNameActor() {
        return actor.getNameActor();
    }

    @Override
    public Queue<Message> getQueue() {
        return null;
    }

    @Override
    public void processMessage(Message message) {

    }

    /**
     * Sends a message to the ActorProxy intercepted by the RespondProxy.
     * @param message the message to be sent
     */
    @Override
    public void sendMessage(Message message) {
        actor.send(message);
    }




}
