package Actors;

import Decorators.NotifyDecorator;
import Message.*;
import java.util.*;
import Observer.*;

import static java.lang.Thread.sleep;

public class RingActorPrint implements Actor {

    private Queue <Message> readBuffer;
    private String name;
    private ActorProxy nextActor;
    private MonitorService monitor;
    private List<String> listInsults;

    private final String [] listPred = new String[]{"Fuck", "Dumb", "Bastard", "Bitch", "Shit"};

    /**
     * Builder of the RingActorPrint class, it also notifies to the MonitorService that an actor
     * has been created.
     * @param name the name of the actor
     * @param nextActor the instance of the next actor of the ring
     */
    public RingActorPrint(String name, ActorProxy nextActor, MonitorService monitor){
        this.monitor = monitor;
        this.nextActor = nextActor;
        this.name = name;
        listInsults = new LinkedList<String>();
        readBuffer = new LinkedList<Message>();
        for(int i = 0; i < listPred.length; i++){
            listInsults.add(listPred[i]);
        }
        Message message =new CreateMessage(null);
        message.setEvent(Event.CREATED);
        monitor.notify(message,this);
    }

    /**
     * Adds a message to its own messages queue
     * @param message the message to be added
     */
    public void sendMessage(Message message) {
        readBuffer.add(message);
    }

    /**
     * Returns the instance of the actor
     * @return an instance of the actor
     */
    public Actor getActor() {
        return this;
    }

    /**
     * Returns the name of the actor
     * @return a string with the name of the actor
     */
    public String getNameActor() {
        return name;
    }

    /**
     * Returns the messages queue of the actor
     * @return a messages queue
     */
    public Queue<Message> getQueue() {
        return readBuffer;
    }

    /**
     * Retrieves and removes the head of its messages queue
     * @return a message of the buffer messages
     */
    @Override
    public Message getMessage() {
        return readBuffer.poll();
    }

    /**
     * Processes the message passed by parameter, depending on the type of message it does a certain action
     * @param message the message to be processed
     */
    @Override
    public void processMessage(Message message) {
        String msg, randInsult;
        ActorProxy name;
        Message mensaje;
        Random rand;
        int randPosInsult;
        ActorContext context = ActorContext.getInstance();
        ActorProxy newAc;

        msg = message.getMessage();
        name = message.getName();

        if (message instanceof GetInsultMessage) {
            rand = new Random();
            randPosInsult = rand.nextInt(listInsults.size());
            randInsult = listInsults.get(randPosInsult);
            System.out.println("(" + this.name + ")" + " receive " + msg +"\n");
            System.out.println("(" + this.name + ")" + " send " +  randInsult + " to actor " + nextActor.getNameActor());
            mensaje = new GetInsultMessage(context.lookup(this.name), randInsult);
            nextActor.sendMessage(mensaje);
        }
        if(message instanceof AddActorMessage){
            if(nextActor == null){
                newAc = context.spawnActor(msg,  new NotifyDecorator(new RingActor(msg,context.lookup(this.name), monitor), monitor));
                nextActor = newAc;
                System.out.println("(" + this.name + ")" + " creates the actor " + msg);
            }
            else if(nextActor.getNameActor().equals(name.getNameActor()) ){
                newAc = context.spawnActor(msg, new NotifyDecorator(new RingActor(msg,nextActor,monitor),monitor));
                nextActor = newAc;
                System.out.println("(" + this.name + ")" + " creates the actor " + msg);
            }
            else{
                nextActor.sendMessage(new AddActorMessage(name, msg));
                System.out.println("(" + this.name + ")" + " send the message: " + msg + " to actor " + nextActor.getNameActor());
            }
        }
        try {
            sleep (2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
