package Actors;


import Message.Message;
import java.util.Queue;


public interface Actor {


     void sendMessage(Message message);

     Actor getActor();

     String getNameActor();

     Queue<Message> getQueue();

     Message getMessage();


     void processMessage(Message message);
}
