package Decorators;

import Actors.Actor;
import Message.*;
import Observer.Event;
import Observer.MonitorService;
import java.util.Queue;

public class NotifyDecorator implements Actor {

    private Actor actor;
    MonitorService monitor;

    /**
     * Builder of the NotifyDecorator class
     * @param actor the instance of the notifier actor
     * @param monitor the instance of the MonitorService
     */
    public NotifyDecorator(Actor actor, MonitorService monitor) {
        this.actor = actor;
        this.monitor = monitor;
    }

    /**
     * Notifies to the MonitorService that a message has been sent to the actor contained in
     * the Decorator by the sender of the message and sends it
     * @param message the message to be sent
     */
    @Override
    public void sendMessage(Message message) {
        Event event = message.getEvent();
        message.setEvent(Event.SENT);
        monitor.notify(message,actor.getActor());
        message.setEvent(event);
        actor.sendMessage(message);
    }

    @Override
    public Actor getActor() {
        return actor.getActor();
    }

    @Override
    public String getNameActor() {
        return actor.getNameActor();
    }

    @Override
    public Queue<Message> getQueue() {
        return actor.getQueue();
    }

    @Override
    public Message getMessage() {
        return actor.getMessage();
    }

    /**
     * Notifies to the MonitorService that a message has been received by the actor contained in
     * the Decorator and processes the message
     * @param message
     */
    @Override
    public void processMessage(Message message) {
        monitor.notify(message,actor.getActor());
        actor.processMessage(message);

    }
}
