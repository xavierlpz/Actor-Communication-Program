package Decorators;

import Actors.Actor;
import Message.Message;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.stream.Stream;

public class EncryptionDecorator implements Actor {
    private Actor actor;

    /**
     * Builder of the EncryptionDecorator class
     * @param actor the actor to be decorated
     */
    public EncryptionDecorator(Actor actor) {
        this.actor = actor;
    }

    /**
     * Encrypts the message passed by parameter and sends it to the actor contained in
     * the Decorator (or another Decorator if there is a pipeline of Decorators)
     * @param message the message to be encrypted and sent
     */
    public void sendMessage(Message message){
        String msg;
        List<Character> msgEnc = new ArrayList<>();

        msg = message.getMessage();

        Stream<Integer> streamMsg = msg.chars().boxed();
        streamMsg.forEach(v -> {v = (v + msg.length()); msgEnc.add((char)(v+0));});
        StringBuilder msgLamb = new StringBuilder();
        msgEnc.stream().forEach(v -> msgLamb.append(v));
        String msgFin = msgLamb.toString();
        message.setMessage(msgFin);
        System.out.println("Encrypted message is: " + msgFin);

        actor.sendMessage(message);
    }

    public Actor getActor() {
        return actor.getActor();
    }

    @Override
    public String getNameActor() {
        return actor.getNameActor();
    }

    @Override
    public Queue<Message> getQueue() {
        return actor.getQueue();
    }

    @Override
    public Message getMessage() {
        return actor.getMessage();
    }

    /**
     * Decrypts the message passed by parameter and processes it
     * @param message the message to be decrypted and sent
     */
    @Override
    public void processMessage(Message message) {
        String msg;

        List<Character> msgEnc = new ArrayList<>();
        msg = message.getMessage();
        Stream<Integer> streamMsg = msg.chars().boxed();
        streamMsg.forEach(v -> {v = (v - msg.length()); msgEnc.add((char)(v+0));});
        StringBuilder msgLamb = new StringBuilder();
        msgEnc.stream().forEach(v -> msgLamb.append(v));
        String msgFin = msgLamb.toString();
        message.setMessage(msgFin);
        actor.processMessage(message);
    }
}
