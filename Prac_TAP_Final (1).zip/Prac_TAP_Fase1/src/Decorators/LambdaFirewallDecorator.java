package Decorators;

import Actors.Actor;
import Message.AddClosureMessage;
import Message.Message;
import Test.DecoratorsTest;

import java.util.Queue;
import java.util.function.Predicate;


public class LambdaFirewallDecorator <T>implements Actor {

    private Actor actor;

    /**
     * Builder of the LambdaFirewallDecorator class
     * @param actor
     */
    public LambdaFirewallDecorator(Actor actor) {
        this.actor = actor;
    }

    /**
     * If the AddClosureMessage passed by parameter meets the established condition, sends
     * the message to the actor contained in the Decorator (or another Decorator if there is
     * a pipeline of Decorators)
     * @param msg the message to be sent
     */
    public  void sendMessage (Message msg) {

       if(msg instanceof AddClosureMessage){
           AddClosureMessage aux = (AddClosureMessage) msg;
           Predicate<T> predicate =  aux.getPredicate();
           if (predicate.test((T)msg.getMessage())) {
               System.out.println("The LambdaFirewall has sent the message");
               actor.sendMessage(msg);
           }
           else
           {
               System.out.println("The LambdaFirewall has refused the message " +msg.getMessage());
               DecoratorsTest.enable = false;
           }

       }
       else {
           actor.sendMessage(msg);
       }

    }

    public Actor getActor() {
        return actor.getActor();
    }

    @Override
    public String getNameActor() {
        return actor.getNameActor();
    }

    @Override
    public Queue<Message> getQueue() {
        return actor.getQueue();
    }

    @Override
    public Message getMessage() {
        return actor.getMessage();
    }

    @Override
    public void processMessage(Message message) {
            actor.processMessage(message);
    }
}
