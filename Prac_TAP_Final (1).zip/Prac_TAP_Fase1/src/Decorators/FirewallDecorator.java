package Decorators;

import Actors.Actor;
import Actors.ActorContext;
import Actors.ActorProxy;
import Message.Message;
import Test.DecoratorsTest;

import java.util.Queue;

public class FirewallDecorator implements Actor {

    private Actor actor;

    /**
     * Builder of the FirewallDecorator class
     * @param actor the actor to be decorated
     */
    public FirewallDecorator(Actor actor) {
        this.actor = actor;
    }

    /**
     * Checks if the sender of the message passed by parameter is a valid actor registered
     * in the ActorContext, if so sends it to the actor contained in the Decorator (or
     * another Decorator if there is a pipeline of Decorators)
     * @param message the message to be sent
     */
    public void sendMessage(Message message){
        ActorContext context = ActorContext.getInstance();
        ActorProxy aux = context.lookup(message.getName().getNameActor());
        if(aux != null){
            actor.sendMessage(message);
        }
        else{
            System.out.println("Firewall activated " + message.getName().getNameActor() + " is not registered\n");
            DecoratorsTest.enable = false;
        }
    }

    public Actor getActor() {
        return actor.getActor();
    }

    @Override
    public String getNameActor() {
        return actor.getNameActor();
    }

    @Override
    public Queue<Message> getQueue() {
        return actor.getQueue();
    }

    @Override
    public Message getMessage() {
        return actor.getMessage();
    }

    @Override
    public void processMessage(Message message)  {
        actor.processMessage(message);
    }
}
